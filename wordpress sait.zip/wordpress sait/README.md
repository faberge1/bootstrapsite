# Верстка черно-белого макета

Верстка черно-белого макета с использованием иконок fontello и jquery для создания интерактивного меню

---

[![GitHub](https://img.shields.io/badge/-Мой_GitHub-333?style=for-the-badge&logo=GitHub&logoColor=fff)](https://github.com/morphIsmail)